from rdflib import Graph
from pyshacl import validate

data_graph = Graph().parse("heron.ttl", format="turtle")
shapes_graph = Graph().parse("heron_shapes.ttl", format="turtle")

results = validate(data_graph, shacl_graph=shapes_graph, inference='rdfs', debug=True)
conforms, report_graph, report_text = results

print("Conforms:", conforms)
print(report_text)